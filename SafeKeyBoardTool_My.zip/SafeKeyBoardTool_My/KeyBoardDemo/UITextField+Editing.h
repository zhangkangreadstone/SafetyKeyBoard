//
//  UITextField+Editing.h
//  KeyBoardDemo
//
//  Created by LSH on 16/1/5.
//  Copyright © 2016年 Practice. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (Editing)


/**
 *  修改textField中的文字
 */
- (void)changeTextFieldText:(NSString *)text;

@end
